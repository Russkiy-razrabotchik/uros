


const scriptsInEvents = {

		async списоксобытий3_Event6_Act2(runtime, localVars)
		{
			runtime.globalVars.popupwn=open("https://budilki.ru","example","width=300,height=300")
			runtime.globalVars.popupwn.focus();
		}

};

self.C3.ScriptsInEvents = scriptsInEvents;

